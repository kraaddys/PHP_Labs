<?php
return [
    'host' => 'localhost',
    'dbname' => 'recipe_book',
    'username' => 'root',
    'password' => '', // по умолчанию в XAMPP пароль пустой
];
